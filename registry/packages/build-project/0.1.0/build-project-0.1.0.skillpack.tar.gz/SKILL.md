---
name: build-project
description: Build source projects into runtime directories using an explicit compiled CLI. Use when Codex needs to verify or run xmake/cmake builds, discover Qt/MSVC installations, set Qt cache entries, or produce a structured runtime_dir JSON result.
---

# Build Project

Use the bundled `build-project` CLI to verify toolchains and build projects into runtime directories.

## Rules

- Pass build parameters explicitly. Do not rely on hidden defaults for type, mode, arch, target, or Qt version.
- Use `--repo` when the current working directory is not the project root.
- Keep machine-specific paths in environment variables or the user config file, not in source repositories.
- Do not package `.env`, local caches, build outputs, or generated runtime directories into a skill.

## Commands

```powershell
build-project verify --repo . --type xmake --mode release --arch x64 --target App --qt-version 6.8.3 --cache-qt
build-project build --repo . --type xmake --mode release --arch x64 --target App --qt-version 6.8.3 --output-dir ./runtime --clean
build-project build --repo . --type cmake --mode release --arch x64 --target App --msvc-version v143 --qt-version 6.8.3
build-project list-qt
build-project list-msvc
```

## Configuration

The CLI reads environment variables first and can cache Qt paths in:

```text
~/hxdSkills/config/build-project.json
```

Supported environment variables:

- `QT_SDK_DIR`: direct Qt SDK path.
- `QT_SEARCH_ROOTS`: semicolon, comma, or whitespace separated Qt search roots.
- `QT_VERSION_KEY`: preferred cached Qt key.
- `QT_SDK_DIR_<VERSION>_<COMPILER>`: explicit Qt version/compiler path.
- `QT_AUTO_CACHE`: `1`, `true`, `yes`, or `on` enables Qt cache writes.
- `PROJECT_NAME`: project name used in runtime path templates.
- `RUNTIME_OUTPUT_DIR`: runtime path template.
- `CMAKE_BUILD_DIR`: override CMake build directory.

Default runtime template:

```text
artifacts/runtime/{project}-{sha}-{os}-{arch}-{mode}
```

## Output

`build` prints a final JSON line:

```json
{"runtime_dir":"D:/project/artifacts/runtime/App-abc1234-windows-x64-release","project":"App","sha":"abc1234","mode":"release","arch":"x64","target":"App","type":"xmake","qt_sdk_dir":"D:/Qt/6.8.3/msvc2022_64","qt_sdk_key":"QT_SDK_DIR_6_8_3_MSVC2022_64"}
```
