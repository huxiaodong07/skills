---
name: nexus
description: Manage Nexus Repository Manager repositories and artifacts from Codex. Use when checking Nexus status, listing or creating repositories, managing Conan hosted/proxy/group repositories, or uploading/downloading raw or Conan artifacts through the bundled nexus CLI.
---

# Nexus

Use the bundled `nexus` CLI for repeatable Nexus Repository Manager operations.

## Configuration

Read credentials from environment variables or pass flags explicitly:

- `NEXUS_URL`: Nexus base URL, default `http://localhost:8081`.
- `NEXUS_USER` or `NEXUS_ADMIN_USER`: basic auth username.
- `NEXUS_PASSWORD` or `NEXUS_ADMIN_PASSWORD`: basic auth password.
- `NEXUS_TOKEN`: bearer token, preferred when available.
- `NEXUS_USE_PROXY`: `true` or `false`; default is `false` for internal Nexus hosts.

Do not write Nexus passwords or tokens into repository files, scripts, plans, logs, or final answers.

## Common Commands

```powershell
nexus status --url http://localhost:8081 --token $env:NEXUS_TOKEN
nexus repos list --format conan
nexus repos get conan-group
nexus repos create-hosted --name conan-internal --format conan
nexus repos create-conan-proxy --name conan-proxy --remote-url https://center.conan.io
nexus repos create-conan-group --name conan-group --members conan-internal,conan-proxy
nexus repos delete old-repo
```

## Artifact Commands

Raw upload uses Nexus' component upload API by default, avoiding direct `PUT` where environments restrict it:

```powershell
nexus artifacts upload --format raw --repository raw-hosted --source dist/app.zip --target releases/app.zip
nexus artifacts download --format raw --repository raw-hosted --source releases/app.zip --destination app.zip
```

Conan operations delegate to the local `conan` CLI:

```powershell
nexus artifacts upload --format conan --reference "pkg/1.0.0@org/stable" --remote-url http://localhost:8081/repository/conan-group --all
nexus artifacts download --format conan --reference "pkg/1.0.0@org/stable" --remote-url http://localhost:8081/repository/conan-group
```

## Boundaries

- Use Nexus APIs for repository management.
- Use format-native clients for complex package workflows when possible.
- Do not infer or hardcode company-specific repository URLs.
- Prefer token-based auth over password-based auth.
