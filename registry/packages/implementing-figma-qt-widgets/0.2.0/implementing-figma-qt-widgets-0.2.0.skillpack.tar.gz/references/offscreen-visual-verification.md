# Offscreen Visual Verification

Use this reference after implementing or changing a Qt Widgets UI from Figma.

## Required Artifacts

- Figma reference PNG.
- Qt offscreen rendered PNG from the real target widget/dialog/application.
- Visual comparison PNG with at least reference and rendered columns; diff or overlay is recommended.
- Optional pixel-diff metrics for locating differences.

## Rendering Requirements

- Use the project's real build output, real QSS loading path, real resources, and real promoted/custom widgets.
- Do not use screenshot-only stubs, placeholder widgets, or simplified visual doubles.
- If the target widget needs data, provide minimal deterministic sample data through the same public or production initialization path that real code uses.
- Use the same Qt version, platform plugin, fonts, and resource paths as the application where possible.

Typical environment variables:

```powershell
$env:QT_QPA_PLATFORM = "offscreen"
$env:QT_SCALE_FACTOR = "1"
$env:QT_PLUGIN_PATH = "<qt-root>/plugins"
$env:QT_QPA_PLATFORM_PLUGIN_PATH = "<qt-root>/plugins/platforms"
```

If Qt reports that no platform plugin could be initialized, set the plugin variables explicitly and confirm the selected Qt `bin` directory is first in `PATH`.

## Agent Visual Check

The agent must actually open or view the comparison image. Inspect:

- Global dimensions and panel hierarchy.
- Positions, alignment, margins, spacing, and stretch behavior.
- Text glyphs, font family, size, weight, color, clipping, and square-box/tofu rendering.
- Borders, dividers, radii, shadows, focus frames, and disabled/checked states.
- Custom-control internals such as chart axes, tick marks, color bar border, slider handles, rulers, and scale labels.
- Icon presence, size, stroke/fill color, and placement.

Build success or low diff metrics are not completion. Completion requires visual acceptance of the rendered image.

## Iteration Order

When the render differs from Figma, fix in this order:

1. Layout hierarchy and widget ownership.
2. Size policies, min/max sizes, stretch factors, margins, and spacing.
3. Fonts and resources.
4. QSS visual details.
5. Control-specific drawing or custom widget behavior.

After every adjustment, render again and view the new comparison.

## Failure Modes

- Blank image: verify widget was shown, events were processed, size is non-zero, and resources loaded.
- Wrong font or square boxes: verify font availability, encoding, locale, and QSS font-family.
- Missing colorbar border or tiny control detail: inspect custom control paint code/QSS and add it to the checklist for future renders.
- Render harness hangs: add phase logs around QApplication construction, widget construction, data initialization, show, processEvents, render, and save.
- Plugin error dialog: configure `QT_QPA_PLATFORM_PLUGIN_PATH` and rerun; the error screenshot is not a valid UI render.

## Completion Gate

Do not mark the task complete unless:

- Offscreen rendering completed successfully.
- The comparison image was viewed by the agent.
- Any visible mismatch was either fixed or explicitly accepted by the user.
