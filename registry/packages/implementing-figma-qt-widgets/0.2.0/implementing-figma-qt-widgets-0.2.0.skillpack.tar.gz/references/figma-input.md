# Figma Input

Use this reference when collecting design information before Qt Widgets implementation.

## Preferred Source

Use Figma MCP when available. Collect:

- File key and node id from the Figma URL.
- Node metadata: size, absolute position, layout mode, constraints, fills, strokes, effects.
- Design context: child hierarchy, component names, variants, states, and text nodes.
- Variables/tokens: colors, radii, spacing, typography, and effects.
- Exported reference screenshot at 1x, and higher scale only when inspecting tiny details.

## Screenshot Rules

- Save the reference screenshot as an artifact with a stable name.
- Preserve its pixel dimensions.
- Note whether the screenshot includes shadows, transparent background, or surrounding frame chrome.
- Compare the same state: selected/disabled/hovered data state must match the Qt render.

## Mapping Figma to Qt

- Translate Figma auto-layout to `QVBoxLayout`, `QHBoxLayout`, `QGridLayout`, or nested layouts before adjusting QSS.
- Treat Figma components as candidates for existing Qt custom widgets or promoted widgets.
- Treat repeated Figma elements as repeated widgets only when they are actually repeated in the UI; do not add business-generated lists unless the design explicitly requires dynamic content.
- Preserve object naming intent: use descriptive object names that make QSS selectors stable.

## Missing Information

If Figma MCP is unavailable or the node lacks enough data:

- Ask for a PNG reference and target viewport size.
- Continue only with clearly stated assumptions.
- Do not claim high-fidelity completion without an offscreen render compared against a visual reference.
