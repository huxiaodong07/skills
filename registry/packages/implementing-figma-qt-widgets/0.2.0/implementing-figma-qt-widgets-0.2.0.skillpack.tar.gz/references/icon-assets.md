# Icon Assets

Use this reference when a button or icon in Figma is missing from the project.

## Search first

Before generating anything, search:

- Existing project image, SVG, icon font, and resource files.
- Existing QSS or `.ui` references to similar icons.
- Figma-exported assets from the target node.
- Public icon sets already present in the project.

Only generate a new icon if no suitable project or Figma asset exists.

## Simple icons: SVG

Use SVG for simple icons:

- Single-color or two-color shapes.
- Geometric or line icons.
- Common actions such as close, search, add, delete, save, arrow, refresh, check, warning.

SVG requirements:

- Use a stable `viewBox`, usually `0 0 16 16`, `0 0 20 20`, or `0 0 24 24`.
- Keep paths clean and minimal.
- Use a neutral fill or stroke that can be recolored by QSS or by editing one attribute.
- Match the Figma stroke width, cap, join, and corner style.

## Complex icons: generated green-screen PNG

Use image generation only for complex icons:

- Multi-color or gradient icons.
- Illustration-like icons.
- Detailed pictograms that would be inaccurate as hand-written SVG.
- Icons with texture, depth, or many small shapes.

Generation requirements:

- Prompt for the icon centered on a pure green `#00ff00` background.
- Request no shadows falling onto the background.
- Request clean, high-contrast edges.
- Generate larger than needed, then downscale after cutting.

Cut the green background with `scripts/cut-green-icon.py` and save a transparent PNG. Add the PNG to the project's normal resource system.

## Verification

Every new icon must appear in the offscreen Qt screenshot and final comparison image. Do not mark an icon complete by inspecting the asset file alone.
