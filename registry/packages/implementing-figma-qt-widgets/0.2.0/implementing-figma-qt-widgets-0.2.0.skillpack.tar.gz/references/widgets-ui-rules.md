# Qt Widgets `.ui` Rules

Use this reference while editing Qt Designer `.ui` files.

## Ownership

- Put persistent visible widgets in `.ui`.
- Use promoted widgets for existing custom controls.
- Keep dynamic creation only for genuinely data-driven repeated content.
- Do not create preview-only replacements for existing project controls.

## Layout First

- Establish top-level layout before placing detailed controls.
- Prefer nested `QVBoxLayout`, `QHBoxLayout`, and `QGridLayout` over absolute geometry.
- Use spacers, stretch factors, size policies, and min/max sizes to match Figma geometry.
- Avoid using QSS padding to correct layout mistakes.

## Object Names

- Give every styled or tested widget a stable `objectName`.
- Use descriptive names based on UI role, not local implementation details.
- Keep names stable so QSS selectors and tests do not break unnecessarily.

## Promoted Widgets

- Search the project for existing controls before adding a new class.
- Promote to the real existing class when Figma shows a chart, slider, color bar, plot, custom button, or custom frame already represented in the project.
- If no suitable control exists, add a real reusable control with production behavior boundaries. Do not add a stub only for screenshot alignment.

## Sizes and Policies

- Match Figma fixed dimensions with min/max only when the design truly requires fixed size.
- Prefer `Preferred` or `Expanding` size policies for responsive regions.
- Use explicit spacing and margins from Figma tokens or measured screenshot values.
- Check that text and icons fit at the target viewport.

## Tab Order and Accessibility

- Keep tab order logical for interactive controls.
- Avoid adding focusable decorative widgets.
- Preserve labels for fields where the existing project pattern supports them.

## Business Logic Boundary

- Do not add business signal-slot connections just because a Figma control looks interactive.
- Existing UI-only visual state wiring is allowed when it is already part of the widget's own presentation contract.
- If replacing a control changes existing semantics, update the existing production signal-slot path consistently instead of leaving the UI disconnected.
