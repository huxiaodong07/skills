# QSS Rules

Use this reference while styling Qt Widgets.

## Hard bans

- Do not add `setStyleSheet(...)` in C++.
- Do not add or keep new `<property name="styleSheet">` blocks in `.ui`.
- Do not hide geometry or layout mistakes with padding hacks.

## File organization

- Put new styles in standalone `.qss` files.
- Prefer the project's existing QSS loading mechanism.
- If adding a new QSS file, add it to the existing resource or deployment system in the least surprising way.
- Keep selectors scoped to widget class and `objectName`.

## Selector pattern

Use object names for screen-specific styling:

```css
QWidget#settingsPanel {
    background: #ffffff;
}

QPushButton#confirmButton {
    min-height: 32px;
    border-radius: 4px;
}
```

Use pseudo-states for visual states only:

```css
QPushButton#confirmButton:hover { }
QPushButton#confirmButton:pressed { }
QPushButton#confirmButton:disabled { }
```

## Resource references

- Reuse existing resource prefixes and deployment paths.
- Prefer resource URLs (`:/...`) when the project already uses Qt resources.
- Keep generated icons in the same asset system as existing icons.
- Add resource manifest entries only when the project requires them.

## QSS timing

Write QSS after the `.ui` layout renders with correct structure and geometry. If the screenshot shows position, spacing, or size errors, fix `.ui` layout first.
