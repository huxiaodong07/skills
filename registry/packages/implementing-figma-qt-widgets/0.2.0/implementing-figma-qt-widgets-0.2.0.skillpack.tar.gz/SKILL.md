---
name: implementing-figma-qt-widgets
description: Use when implementing or refining a Qt Widgets UI from a Figma design node, especially when high-fidelity .ui layout, standalone QSS, real project widgets, icon assets, and offscreen visual verification are required.
---

# Implementing Figma Qt Widgets

Implement Figma screens as production Qt Widgets UI. Optimize for fidelity without inventing business behavior.

## Required Inputs

- Figma node URL or node id, preferably available through Figma MCP.
- Target Qt Widgets screen, dialog, or widget class.
- Current project build/run method and Qt version.

Read these references only when needed:

- `references/figma-input.md`: Figma MCP extraction and screenshot input.
- `references/widgets-ui-rules.md`: `.ui`, layout, object name, promoted widget, and tab-order rules.
- `references/qss-rules.md`: standalone QSS and selector rules.
- `references/icon-assets.md`: missing icon search/generation rules.
- `references/offscreen-visual-verification.md`: screenshot, comparison, and AI visual loop.

## Hard Rules

- Put every non-dynamic visible widget in `.ui`.
- Put QSS only in standalone `.qss` files. Do not add inline QSS in C++ or `.ui`.
- Implement UI only. Do not infer business flows, data loading, backend calls, or new signal-slot behavior.
- Use real project widgets. Do not replace existing controls with preview stubs, screenshot-only widgets, fake placeholders, or simplified visual doubles.
- Search existing widgets, icons, QSS, resource files, and promoted classes before adding anything new.
- If a needed control does not exist, add a real reusable project control or extend the closest existing one in production code; do not bypass it for visual convenience.
- Judge completion only from the Qt offscreen rendered result viewed by the agent, not from code appearance, build success, or diff numbers alone.

## Implementation Order

1. Inspect the target project: build system, Qt version, existing style loading, existing widgets, resources, fonts, and screenshots.
2. Fetch Figma node metadata, design context, variables/tokens, text styles, and reference screenshot.
3. Map the global layout first: top-level size, bands, splitters, major panels, stretch factors.
4. Map local layouts: rows, columns, nested layout ownership, alignment, spacing, margins.
5. Place widgets in `.ui`: object names, promoted widgets, size policies, min/max sizes, buddy labels, tab order.
6. Build and render once before styling. Fix layout, sizes, margins, spacing, and size policies before QSS.
7. Add or update standalone QSS after geometry is correct.
8. Render offscreen, create visual comparison, view the image, and iterate until the rendered UI matches Figma.

## Visual Verification Checklist

- Overall window/frame size, panel hierarchy, layout proportions, alignment, margins, and spacing.
- Fonts, glyph rendering, text truncation, text color, weight, and line height.
- Backgrounds, borders, dividers, radii, shadows, and disabled/hover/checked states.
- Icon shape, stroke/fill, size, placement, and missing resources.
- Real custom controls, including internal borders, handles, rulers, scales, color bars, and chart chrome.
- Overflow, overlap, clipped text, empty regions, unintended focus frames, and platform-plugin error dialogs.

If the environment cannot display images, stop before declaring completion and ask for a usable image-viewing path.

## Common Failure Responses

- Text renders as square boxes: inspect font availability, encoding, locale, Qt platform plugin setup, and whether the rendered path uses the same font/QSS as the app.
- A border or small visual detail is missed: add that detail to the visual checklist for the control class and re-render; do not rely on overall similarity.
- Offscreen render needs a missing widget: link the real widget and dependencies, or add the real production widget first. Do not use a stub.
- Pixel diff disagrees with visual judgement: use diff only to locate differences; final acceptance requires viewing the rendered comparison image.
- Qt platform plugin fails: set `QT_QPA_PLATFORM`, `QT_PLUGIN_PATH`, and `QT_QPA_PLATFORM_PLUGIN_PATH` explicitly, then rerun.

## Script Helpers

- `scripts/check-widget-ui-rules.ps1`: static guardrail scan for inline QSS, `.ui` styleSheet blocks, suspicious static widget creation in C++, and business `connect(...)` edits.
- `scripts/make-visual-comparison.py`: create side-by-side reference/rendered/diff or overlay images.
- `scripts/image-diff-metrics.py`: produce auxiliary diff metrics only.
- `scripts/cut-green-icon.py`: convert green-screen generated complex icons into transparent PNG.
