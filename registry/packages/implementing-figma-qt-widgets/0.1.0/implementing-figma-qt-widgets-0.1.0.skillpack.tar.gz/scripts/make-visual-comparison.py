#!/usr/bin/env python3
"""Create a side-by-side visual comparison image for Figma and Qt screenshots."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFont


PADDING = 16
LABEL_H = 28
GAP = 16


def pixel_data(image: Image.Image):
    if hasattr(image, "get_flattened_data"):
        return image.get_flattened_data()
    return image.getdata()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reference", type=Path, help="Figma reference PNG")
    parser.add_argument("rendered", type=Path, help="Qt rendered PNG")
    parser.add_argument("output", type=Path, help="Output comparison PNG")
    parser.add_argument("--tolerance", type=int, default=0, help="Per-channel diff tolerance")
    parser.add_argument("--no-diff", action="store_true", help="Only render reference and rendered panels")
    return parser.parse_args()


def load_rgba(path: Path) -> Image.Image:
    if not path.exists():
        raise FileNotFoundError(path)
    return Image.open(path).convert("RGBA")


def fit_panel(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    panel = Image.new("RGBA", size, (255, 255, 255, 255))
    panel.alpha_composite(image, (0, 0))
    return panel


def make_diff(reference: Image.Image, rendered: Image.Image, size: tuple[int, int], tolerance: int) -> Image.Image:
    ref_panel = fit_panel(reference, size)
    ren_panel = fit_panel(rendered, size)
    diff = ImageChops.difference(ref_panel, ren_panel)
    heat = Image.new("RGBA", size, (255, 255, 255, 255))
    heat_data = []
    for pixel in pixel_data(diff):
        if max(pixel) > tolerance:
            heat_data.append((255, 0, 0, 220))
        else:
            heat_data.append((245, 245, 245, 255))
    heat.putdata(heat_data)
    return heat


def draw_panel(canvas: Image.Image, image: Image.Image, x: int, y: int, title: str, font: ImageFont.ImageFont) -> None:
    draw = ImageDraw.Draw(canvas)
    draw.text((x, y), title, fill=(0, 0, 0), font=font)
    draw.rectangle((x - 1, y + LABEL_H - 1, x + image.width, y + LABEL_H + image.height), outline=(180, 180, 180))
    canvas.alpha_composite(image, (x, y + LABEL_H))


def main() -> int:
    args = parse_args()
    reference = load_rgba(args.reference)
    rendered = load_rgba(args.rendered)

    panel_size = (max(reference.width, rendered.width), max(reference.height, rendered.height))
    panels = [
        ("FIGMA REFERENCE", fit_panel(reference, panel_size)),
        ("QT RENDERED", fit_panel(rendered, panel_size)),
    ]
    if not args.no_diff:
        panels.append(("DIFF HEATMAP", make_diff(reference, rendered, panel_size, max(0, args.tolerance))))

    width = PADDING * 2 + len(panels) * panel_size[0] + (len(panels) - 1) * GAP
    height = PADDING * 2 + LABEL_H + panel_size[1]
    canvas = Image.new("RGBA", (width, height), (250, 250, 250, 255))
    font = ImageFont.load_default()

    x = PADDING
    y = PADDING
    for title, image in panels:
        draw_panel(canvas, image, x, y, title, font)
        x += panel_size[0] + GAP

    if reference.size != rendered.size:
        draw = ImageDraw.Draw(canvas)
        msg = f"SIZE MISMATCH reference={reference.width}x{reference.height} rendered={rendered.width}x{rendered.height}"
        draw.rectangle((PADDING, height - PADDING - 18, width - PADDING, height - PADDING), fill=(255, 240, 180))
        draw.text((PADDING + 4, height - PADDING - 16), msg, fill=(0, 0, 0), font=font)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    canvas.convert("RGB").save(args.output)
    print(f"comparison_output={args.output}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"error={exc}", file=sys.stderr)
        raise SystemExit(2)
