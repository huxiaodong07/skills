#!/usr/bin/env python3
"""Remove a pure green-screen background from a generated icon."""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

from PIL import Image


def pixel_data(image: Image.Image):
    if hasattr(image, "get_flattened_data"):
        return image.get_flattened_data()
    return image.getdata()


def parse_color(value: str) -> tuple[int, int, int]:
    if value.startswith("#") and len(value) == 7:
        return tuple(int(value[i : i + 2], 16) for i in (1, 3, 5))  # type: ignore[return-value]
    parts = value.split(",")
    if len(parts) != 3:
        raise argparse.ArgumentTypeError("Color must be #rrggbb or r,g,b")
    return tuple(int(part.strip()) for part in parts)  # type: ignore[return-value]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Generated green-screen icon")
    parser.add_argument("output", type=Path, help="Transparent PNG output")
    parser.add_argument("--green", type=parse_color, default=(0, 255, 0), help="Green-screen color, default #00ff00")
    parser.add_argument("--tolerance", type=float, default=35.0, help="Euclidean RGB tolerance")
    parser.add_argument("--trim", action="store_true", help="Trim transparent bounds after cutting")
    return parser.parse_args()


def distance(a: tuple[int, int, int], b: tuple[int, int, int]) -> float:
    return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(3)))


def main() -> int:
    args = parse_args()
    if not args.input.exists():
        raise FileNotFoundError(args.input)

    image = Image.open(args.input).convert("RGBA")
    green = args.green
    tolerance = max(0.0, args.tolerance)
    output_pixels = []
    removed = 0

    for r, g, b, a in pixel_data(image):
        if distance((r, g, b), green) <= tolerance:
            output_pixels.append((r, g, b, 0))
            removed += 1
        else:
            output_pixels.append((r, g, b, a))

    image.putdata(output_pixels)

    if args.trim:
        bbox = image.getbbox()
        if bbox:
            image = image.crop(bbox)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    image.save(args.output)
    total = image.width * image.height
    print(f"output={args.output}")
    print(f"transparent_pixels_removed={removed}")
    print(f"output_size={image.width}x{image.height}")
    print(f"remaining_pixels={total}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"error={exc}", file=sys.stderr)
        raise SystemExit(2)
