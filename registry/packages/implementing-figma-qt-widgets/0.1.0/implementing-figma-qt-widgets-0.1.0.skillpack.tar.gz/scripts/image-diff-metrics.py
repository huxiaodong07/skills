#!/usr/bin/env python3
"""Report image difference metrics for visual UI checks."""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

from PIL import Image, ImageChops


def pixel_data(image: Image.Image):
    if hasattr(image, "get_flattened_data"):
        return image.get_flattened_data()
    return image.getdata()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reference", type=Path, help="Figma reference PNG")
    parser.add_argument("rendered", type=Path, help="Qt rendered PNG")
    parser.add_argument("--diff-output", type=Path, help="Optional diff heatmap PNG")
    parser.add_argument("--tolerance", type=int, default=0, help="Per-channel tolerance, default 0")
    return parser.parse_args()


def load_rgba(path: Path) -> Image.Image:
    if not path.exists():
        raise FileNotFoundError(path)
    return Image.open(path).convert("RGBA")


def main() -> int:
    args = parse_args()
    reference = load_rgba(args.reference)
    rendered = load_rgba(args.rendered)

    if reference.size != rendered.size:
        print(f"size_match=false reference={reference.size[0]}x{reference.size[1]} rendered={rendered.size[0]}x{rendered.size[1]}")
        return 2

    diff = ImageChops.difference(reference, rendered)
    pixels = pixel_data(diff)
    total = reference.size[0] * reference.size[1]
    changed = 0
    squared = 0
    max_delta = 0
    tolerance = max(0, args.tolerance)

    for pixel in pixels:
        delta = max(pixel)
        max_delta = max(max_delta, delta)
        squared += sum(channel * channel for channel in pixel[:3])
        if delta > tolerance:
            changed += 1

    changed_percent = (changed / total * 100.0) if total else 0.0
    rms = math.sqrt(squared / (total * 3)) if total else 0.0
    bbox = diff.convert("RGB").getbbox()

    print("size_match=true")
    print(f"pixels_total={total}")
    print(f"pixels_changed={changed}")
    print(f"pixels_changed_percent={changed_percent:.6f}")
    print(f"max_channel_delta={max_delta}")
    print(f"rms_delta={rms:.6f}")
    print(f"bounding_box={bbox if bbox else 'none'}")

    if args.diff_output:
        heat = Image.new("RGBA", reference.size, (0, 0, 0, 0))
        out = []
        for pixel in pixel_data(diff):
            if max(pixel) > tolerance:
                out.append((255, 0, 0, 220))
            else:
                out.append((0, 0, 0, 0))
        heat.putdata(out)
        args.diff_output.parent.mkdir(parents=True, exist_ok=True)
        heat.save(args.diff_output)
        print(f"diff_output={args.diff_output}")

    return 1 if changed else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"error={exc}", file=sys.stderr)
        raise SystemExit(2)
