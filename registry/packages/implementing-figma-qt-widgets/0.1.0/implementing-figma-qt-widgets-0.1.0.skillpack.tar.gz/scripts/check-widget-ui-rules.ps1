param(
    [Parameter(Mandatory = $true)]
    [string]$Path
)

$ErrorActionPreference = "Stop"

$root = Resolve-Path -LiteralPath $Path
$findings = New-Object System.Collections.Generic.List[object]

function Add-Finding {
    param(
        [string]$File,
        [int]$Line,
        [string]$Rule,
        [string]$Text
    )
    $findings.Add([pscustomobject]@{
        File = $File
        Line = $Line
        Rule = $Rule
        Text = $Text.Trim()
    })
}

function Read-LinesSafe {
    param([string]$File)
    try {
        return Get-Content -LiteralPath $File -Encoding UTF8
    } catch {
        return Get-Content -LiteralPath $File
    }
}

$files = Get-ChildItem -LiteralPath $root -Recurse -File |
    Where-Object {
        $_.FullName -notmatch '\\(build|\.xmake|\.git|\.vs|dist|\.codex\\artifacts)\\' -and
        $_.Extension -in @(".cpp", ".cc", ".cxx", ".h", ".hpp", ".ui", ".qss")
    }

foreach ($file in $files) {
    $lines = Read-LinesSafe $file.FullName
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $line = [string]$lines[$i]
        $lineNo = $i + 1

        if ($file.Extension -in @(".cpp", ".cc", ".cxx", ".h", ".hpp")) {
            if ($line -match '\bsetStyleSheet\s*\(') {
                Add-Finding $file.FullName $lineNo "inline-qss-cpp" $line
            }
            if ($line -match '\bconnect\s*\(') {
                Add-Finding $file.FullName $lineNo "review-connect-business-boundary" $line
            }
            if ($line -match '\bnew\s+Q[A-Za-z0-9_]+\s*\(' -and $line -notmatch 'QSpacerItem|QAction|QShortcut|QMenu') {
                Add-Finding $file.FullName $lineNo "review-static-widget-in-cpp" $line
            }
        }

        if ($file.Extension -eq ".ui") {
            if ($line -match '<property name="styleSheet">') {
                Add-Finding $file.FullName $lineNo "inline-qss-ui" $line
            }
            if ($line -match '<widget class="Q[A-Za-z0-9_]+" name="[^"]*placeholder|preview|stub') {
                Add-Finding $file.FullName $lineNo "review-preview-stub-widget" $line
            }
        }
    }
}

if ($findings.Count -eq 0) {
    Write-Output "No widget UI rule findings."
    exit 0
}

$findings | Format-Table -AutoSize
exit 1
